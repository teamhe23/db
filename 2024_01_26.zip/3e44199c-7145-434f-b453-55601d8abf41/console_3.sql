--insert into EDSR.HP_VTEX_PRODUCTO
select prd_lvl_child
from edsr.tpprdmst prd
where prd.prd_lvl_number in ('24804')
  and not exists(select 1 from EDSR.HP_VTEX_PRODUCTO x where x.prd_lvl_child = prd.prd_lvl_child);

select * from edsr.HP_VTEX_PRODUCTO where prd_lvl_child = 114016;

SELECT ORG_LVL_NUMBER,
             PRD_LVL_NUMBER,
             CANTIDAD
      FROM VTEX_STOCK_DIFF;

-- PKG_VTEX_INTEGRACION_STOCK