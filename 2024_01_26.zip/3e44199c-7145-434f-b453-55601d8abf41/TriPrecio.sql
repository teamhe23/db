
select * from edsr.tpprdmst where prd_lvl_number = '10101'; --tabla maestra de producto general (aplanada)
select * from edsr.hprangoprecio where sku = '10101';
select * from edsr.dpc_tienda_campana;

/*
update edsr.hprangoprecio set inicio = trunc(sysdate);
--where sku = '10101'
COMMIT;

Probar omitiendo
       campaignDescription
       campaignStartDate
       campaignEndDate
       campaignBranches

es un job, que se ejecuta una vez al día (5:00am); enviando las promos de volumen al DPC
por cada fila del select un JSON y una promo en DPC
EDSR.PKG_DPC_RANGO_PRECIO

*/
SELECT * FROM edsr.dpc_tienda_campana TC;
UPDATE edsr.dpc_tienda_campana TC SET SUCURSAL = 2;

SELECT TC.SUCURSAL,
       TC.ID_CAMPANA,
       TC.Des_Campana,
       LPAD(TRIM(R.SKU), 9, 0) SKU,
       R.PRECIO,
       R.RANGO1 CANTIDAD1,
       R.PRECIO1,
       R.RANGO2 CANTIDAD2,
       R.PRECIO2,
       R.INICIO,
       R.FIN,
       SUBSTR(R.DESCRIPCION,0,40) AS DESC_PROMO
FROM EDSR.HPRANGOPRECIO R
    INNER JOIN edsr.dpc_tienda_campana TC ON TC.SUCURSAL = R.SUCURSAL
WHERE R.INICIO = TRUNC(SYSDATE);

SELECT * FROM EDSR.HPRANGOPRECIO;
SELECT * FROM edsr.dpc_tienda_campana;


-- PROCEDURE SP_GET_PRODUCTO_SIN_TRIPRECIO
SELECT LPAD(TRIM(C.PRODUCT_NUMBER), 9, 0) PRD_LVL_NUMBER,
             C.ORG_LVL_NUMBER
FROM EDSR.CHLPRCE2 C
WHERE C.PRC_FROM_DATE >= trunc(sysdate) - 10
      AND C.PRC_QTY_BRK_ID IS NULL
GROUP BY C.PRODUCT_NUMBER, C.ORG_LVL_NUMBER;


SELECT LPAD(TRIM(C.PRODUCT_NUMBER), 9, 0) PRD_LVL_NUMBER,
             C.ORG_LVL_NUMBER
FROM EDSR.CHLPRCE2 C;

SELECT * FROM EDSR.CHLPRCE2;

SELECT * FROM ALL_SYNONYMS WHERE SYNONYM_NAME = 'CHLPRCE2';
SELECT * FROM ALL_SYNONYMS WHERE SYNONYM_NAME = 'dpc_tienda_campana';

