declare
begin
    DBMS_OUTPUT.PUT_LINE('dsadsa');
end;


declare
    INVAL NUMBER := 0;
begin
    EDSR.PKG_PIVOT_STUPENDO.SIMPLEPROCEDURE(INVAL => INVAL);
end;

SELECT * FROM EDSR.B2BACKEE2