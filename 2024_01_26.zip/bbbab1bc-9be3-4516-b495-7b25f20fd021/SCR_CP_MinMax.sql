DECLARE
    TOTAL NUMBER := 0;
    MINIMO NUMBER := 0;
    MAXIMO NUMBER := 0;

    p_secuencia NUMBER;

    V_PRD_LVL_NUMBER VARCHAR2(15);

BEGIN
    SELECT COUNT(*)
     INTO TOTAL
    FROM EDSR.temp_CargaMasivaMinMax;

    IF TOTAL > 0 THEN
        SELECT MIN(ID), MAX(id)
        INTO MINIMO,MAXIMO
        FROM EDSR.temp_CargaMasivaMinMax
        --WHERE ID <=50 --OPCIONAL
        ;

        SELECT EDSR.TP_SEQ_RPL_SEQ.NEXTVAL
        INTO p_secuencia
        FROM DUAL;

       DBMS_OUTPUT.PUT_LINE('TOTAL: ' || TOTAL);
       DBMS_OUTPUT.PUT_LINE('MINIMO: ' || MINIMO);
       DBMS_OUTPUT.PUT_LINE('MAXIMO: ' || MAXIMO);

        WHILE MINIMO <= MAXIMO LOOP
            SELECT E_PRODUCTO
            INTO V_PRD_LVL_NUMBER
            FROM EDSR.temp_CargaMasivaMinMax
            WHERE ID = MINIMO;


            UPDATE EDSR.temp_CargaMasivaMinMax
                SET
                    RPL_SEQ = p_secuencia,
                    RPL_SEQ_REG = ID,
                    RPL_METHOD_CODE = 1,
                    PRD_LVL_CHILD = S_OBT_PRODUCTO(E_PRODUCTO),
                    ORG_LVL_CHILD = S_OBT_SUCURSAL(E_TIENDA),
                    RPL_DIST_METHOD = CASE WHEN E_METODO_RPL = 'OCS' THEN 2
                                           WHEN E_METODO_RPL = 'CAT' THEN 6
                                           WHEN E_METODO_RPL = 'RAT' THEN 3
                                       END,
                    RPL_MIN_STK = E_MIN ,
                    RPL_MAX_STK = E_MAX,
                    USR_CRE = 'SISTEMAS'
                WHERE ID = MINIMO;

            MINIMO := MINIMO + 1 ;
            --DBMS_OUTPUT.PUT_LINE(V_PRD_LVL_NUMBER);
            COMMIT;
        END LOOP;

       INSERT INTO EDSR.TPCARPAR
          (
           RPL_SEQ,
           RPL_SEQ_REG,
           RPL_METHOD_CODE,
           PRD_LVL_CHILD,
           ORG_LVL_CHILD,
           RPL_DIST_METHOD,
           RPL_MIN_STK,
           RPL_MAX_STK,
           USR_CRE,
           FEC_CRE
          )
        SELECT
           RPL_SEQ,
           RPL_SEQ_REG,
           RPL_METHOD_CODE,
           PRD_LVL_CHILD,
           ORG_LVL_CHILD,
           RPL_DIST_METHOD,
           RPL_MIN_STK,
           RPL_MAX_STK,
           USR_CRE,
           sysdate
        FROM temp_CargaMasivaMinMax
        --WHERE ID <=50 --OPCIONAL
        ;
       COMMIT;

       -- Busca los productos que no tienen habilitado el cross-docking y los borra
        INSERT INTO TPCARPAR_REC_TMP
          (RPL_SEQ, RPL_SEQ_REG, PRD_LVL_CHILD, ORG_LVL_CHILD)
          SELECT T1.RPL_SEQ, T1.RPL_SEQ_REG, T1.PRD_LVL_CHILD, T1.ORG_LVL_CHILD
            FROM TPCARPAR T1
           INNER JOIN TPPRDMST P
              ON T1.PRD_LVL_CHILD = P.PRD_LVL_CHILD
           WHERE RPL_SEQ = p_secuencia
             AND RPL_DIST_METHOD = 6 -- CAT
             AND (P.VPC_TECH_KEY, P.COD_AREA, T1.ORG_LVL_CHILD) NOT IN
                 (SELECT PRV_AREA.VPC_TECH_KEY, PRV_AREA.COD_AREA, AO.ORG_LVL_CHILD
                    FROM (SELECT DISTINCT PC1.VPC_TECH_KEY, TA.COD_AREA, TCD.TIPO
                            FROM HP_CROSS_PROV PC1
                           CROSS JOIN (SELECT TRIM(PRD_LVL_NUMBER) COD_AREA
                                        FROM PRDMSTEE
                                       WHERE PRD_LVL_ID = 4) TA
                           CROSS JOIN (SELECT DISTINCT TIPO FROM HP_CROSS_PROV) TCD) PRV_AREA
                    LEFT JOIN HP_CROSS_PROV PC2
                      ON PC2.VPC_TECH_KEY = PRV_AREA.VPC_TECH_KEY
                     AND PC2.TIPO = PRV_AREA.TIPO
                     AND PC2.COD_AREA IS NULL
                    LEFT JOIN HP_CROSS_PROV PC3
                      ON PC3.VPC_TECH_KEY = PRV_AREA.VPC_TECH_KEY
                     AND PC3.TIPO = PRV_AREA.TIPO
                     AND PC3.COD_AREA = PRV_AREA.COD_AREA
                    LEFT JOIN BASACDEE CA
                      ON NVL(PC3.TIPO, PC2.TIPO) = CA.ATR_COD_TECH_KEY
                    LEFT JOIN BASATOEE AO
                      ON CA.ATR_COD_TECH_KEY = AO.ATR_COD_TECH_KEY
                    LEFT JOIN HP_CROSS_SUC SC
                      ON NVL(PC2.ID, PC3.ID) = SC.ID
                     AND AO.ORG_LVL_CHILD = SC.ORG_LVL_CHILD
                    LEFT JOIN ORGMSTEE O
                      ON AO.ORG_LVL_CHILD = O.ORG_LVL_CHILD
                   WHERE NOT NVL(PC2.ID, PC3.ID) IS NULL
                     AND SC.ORG_LVL_CHILD IS NULL);

        DELETE FROM TPCARPAR
        WHERE (RPL_SEQ, RPL_SEQ_REG) IN
                (SELECT RPL_SEQ, RPL_SEQ_REG
                 FROM TPCARPAR_REC_TMP
                 WHERE RPL_SEQ = p_secuencia);



        COMMIT;
    ELSE
        DBMS_OUTPUT.PUT_LINE('No se encontraron registros');
    END if;
END;

-- temp_CargaMasivaMinMax
SELECT COUNT(1) FROM EDSR.temp_CargaMasivaMinMax;
-- TPCARPAR
SELECT COUNT(1) FROM EDSR.TPCARPAR;

SELECT * FROM EDSR.temp_CargaMasivaMinMax order by ID;

SELECT RPL_SEQ,RPL_SEQ_REG,RPL_METHOD_CODE,PRD_LVL_CHILD,ORG_LVL_CHILD,RPL_DIST_METHOD,RPL_MIN_STK,RPL_MAX_STK,USR_CRE,FEC_CRE
 FROM EDSR.TPCARPAR;

/*

 Secuencia 75 (DESDE SCRIPT)
 Secuencia 76 (TODO 777 OCS DESDE SCRIPT)
 Secuencia 77 (TODO 142 RAT DESDE SCRIPT)
*/

BEGIN
    EDSR.TP_PKG_REPDIN.SP_CARGA_PARAM_REPO(77,'SISTEMAS');
END;




-- TRUNCATE TABLE EDSR.temp_CargaMasivaMinMax;
-- DROP SEQUENCE EDSR.TEMP_CargaMasivaMinMax_SEQ;
CREATE SEQUENCE EDSR.TEMP_CargaMasivaMinMax_SEQ
    START WITH 1
    INCREMENT BY 1
    NOMAXVALUE
    NOCYCLE;



/*
DROP FUNCTION EDSR.S_OBT_PRODUCTO;
DROP FUNCTION EDSR.S_OBT_SUCURSAL;
*/

CREATE OR REPLACE FUNCTION EDSR.S_OBT_PRODUCTO(PPRD_LVL_NUMBER IN VARCHAR2)
RETURN NUMBER
IS
    PPROD_COUNT  NUMBER := 0;
    V_PRD_LVL_CHILD NUMBER := 0;
BEGIN
     SELECT COUNT(PRD.PRD_LVL_CHILD)
       INTO PPROD_COUNT
       FROM TPPRDMST PRD
      WHERE PRD.PRD_LVL_ID = 1
        AND PRD.PRD_STYLE_IND = 'T'
        AND PRD.PRD_LVL_NUMBER = PPRD_LVL_NUMBER;

     IF PPROD_COUNT = 0 THEN
        SELECT PRD.PRD_LVL_CHILD
          INTO V_PRD_LVL_CHILD
          FROM TPPRDMST PRD
         WHERE PRD.PRD_LVL_ID IN (0,1)
           AND PRD.PRD_STYLE_IND = 'F'
           AND PRD.PRD_LVL_NUMBER = PPRD_LVL_NUMBER;
     END IF;

     RETURN V_PRD_LVL_CHILD;

END;

CREATE OR REPLACE FUNCTION EDSR.S_OBT_SUCURSAL(PORG_LVL_NUMBER IN NUMBER)
RETURN NUMBER
IS
    PPROD_COUNT  NUMBER := 0;
    PORG_LVL_CHILD NUMBER := 0;
BEGIN
     SELECT COUNT(ORG.ORG_LVL_CHILD)
     INTO PPROD_COUNT
     FROM ORGMSTEE ORG
     WHERE ORG.ORG_LVL_ID = 1
       AND ORG.ORG_LVL_NUMBER = PORG_LVL_NUMBER;

     IF PPROD_COUNT > 0 THEN
         SELECT ORG.ORG_LVL_CHILD
           INTO PORG_LVL_CHILD
         FROM ORGMSTEE ORG
         WHERE ORG.ORG_LVL_ID = 1
            AND ORG.ORG_LVL_NUMBER = PORG_LVL_NUMBER;
     END IF;

     RETURN PORG_LVL_CHILD;

END;

SELECT S_OBT_PRODUCTO('25403') AS PRD_LVL_CHILD FROM DUAL;
SELECT S_OBT_SUCURSAL(103) AS ORG_LVL_CHILD FROM DUAL;